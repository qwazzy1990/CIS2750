

#ifndef _GEDCOM_UTILITIES_
#define _GEDCOM_UTILITES_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <stdbool.h>
#include "LinkedListAPI.h"
#include "GEDCOMparser.h"

#define MAX_LEN 255
#define NUM_TAGS 135
#define NUM_INDI_EVENTS 23
#define NUM_FAM_EVENTS 12




struct genGedOb{
   Header* header;
   List families;
   List individuals;
   Submitter* submitter;

};typedef struct genGedOb TestGED;

/**
    Object of type gedcom line
    contains level number tag pointer
    xref ID and value
*/
struct GEDline {
    char* level;
    char* tag;
    char* pointer;
    char* ID;
    char* value;
    int lineNumber;
}; typedef struct GEDline GEDline;


struct record{
    GEDline** info;
    int size;
}; typedef struct record Record;


struct indi{
    char* type;
    char* pointer;
    char** spouseOf;
    char** childOf;
    char* givenName;
    char* surname;

    Individual* individual;
    List families;
    List events;
    List otherFields;
};typedef struct indi IndividualCopy;

struct fami{
  char* pointer;
  char* type;
  char* husbandLink;
  char* wifeLink;
  char** childrenLinks;

  Family* family;
  Individual* husband;
  Individual* wife;
  List children;
  List otherFields;
  List events;
};typedef struct fami FamilyCopy;


struct h{
    //Tag for the submitter//
   char submitterTag[10];

   char source[249];

   float gedcVersion;

   CharSet encoding;

   Submitter* submitter;

   List otherFields;
};typedef struct h HeaderCopy;



struct s{

  char pointer[10];
  char submitterName[69];
  List otherFields;
  char address[];
}; typedef struct s SubmitterCopy;


/*****************FILE OPENING FUNCTIONS********************/

FILE* openFile(char* fileName);
void fileCloser(FILE* FP);
char** returnFile(FILE* FP, int* lineNumber);
char* readFile(char* buffer, int max, FILE* FP);
	//**********************FUNCTIONS TO MUTATE STRINGS***********************/
/**
    Function to remobe leading whie space of string
    Returns a new copy of the string without
    leadng white space
*/

      /*********String Helper Functions*********/
char** tokenizeString(char* s, int arraySize);
char* removeLeadingWhiteSpace(char* s);
void removeHardReturn(char* s);
void removeTrailingWhiteSpace(char* s);
/**
   fucntion to create a pointer to a generinGED
   param = arrayOfStrinhs
   return = generic genOb;*
*/

char* stringCopy(char* original);
char* appendSpace(char* s);
/**Function to concatenate an array of strings to a string**/
char* stringcatArray(char** source, int start, int numTimes, char* s);

bool strequal(const void* first, const void* second);

char** stringarrayCopy(char** array, int start, int end);

char** tokenizeName(char* name);



int stringToInt(void* data);
char* stringCat(char* dest, char* source);
char* emptyString();






 //check of file is empty
bool isFileEmpty(FILE* fp);


bool containsValidLineLength(FILE* fp);

    /****CHECK IF OBJECTS AND STRINGS EXIST********/
bool doesObjectExist(void* a);
bool doesStringExist(char* s);


            /****************VALIDATE GEDCOM OBJECT******************/

GEDCOMerror generalValidator(List* gedLineList, HeaderCopy* header, SubmitterCopy* s, List* iCopyList, List* fCopyList, int* n, GEDCOMerror* e);

bool validLevelNumbers(List* l, int* lineNumber);

bool validHeader(HeaderCopy* h);

bool validSubmitter(SubmitterCopy* s);

bool validTrailer(List* l);

bool validGEDCOM(List* l);


int getNumberOfLines(FILE* fp, int* lineNumber);

//General purpose parser. Parses based on spaces
//Splits string into substrings

void parseBySpace(char* s);

//parses strings into sub strings
char** tokenizeString(char* s, int arraySize);


void printArrayOfStrings(char** s);

int getLineSize(char* line);
/**
   Tokenize string with runknown number of tokens
*/
int getNumTokens(char* s);

    /***GETS THE NUMBER OF NAMES*******/
int getNumNames(char* s);

int getNumChildren(char** s);
/**
    creates memory for a stiring
    and returns in
*/

/**
	         **************CLONERS***************
*/
Event* cloneEvent(void* original);


Field* cloneField(void* original);


Submitter* cloneSubmitter(void* original);


Header* cloneHeader(void* original);


Individual* cloneIndividual(void* original);


Family* cloneFamily(void* original);


GEDCOMobject* cloneGEDobject(void* original);


GEDline* cloneGEDline(GEDline* original);


IndividualCopy* cloneIndividualCopy(void* original);


FamilyCopy* cloneFamilyCopy(void* original);


void cloneFamilyList(List* dest, List* source);
void cloneIndividualList(List* dest, List* source);

/*
	FUNCTIONS TO CHECK STATUS OF STRINGS
*/
/**
   checks if it is a tag
    ca;;s function allCaps
*/
bool validTag(char* s);
    /*********CHECK IF IT IS A VALID EVENT TAGE FOR AN INDIVIDUAL*******/
bool validIndiEventTag(char* s);

bool validFamEventTag(char* s);

bool validNumber(char* s);

/**
   Checks if string is a pointer
*/
bool validPointer(char* s);

/**
    Chekcs if sring is all caps
*/
bool allCaps(char* s);

/**
    Checks of string is a valid XREF_ID
    or Pointer
*/

bool validXREFid(char* s);


bool validFileName(char* s);

	/**
	 **************FUNCTIONS TO ADD ELEMENTS FROM LISTS TO ARRAYS/OTHER LSTS*****8
	**/

void addLineNums(List l);



	/***********PRINT FUCNTIONS***************/


char* printString(void* data);





		      /*********BASIC CONSTRUCTORS***********/

char* stringAllocater(char* s);


char** stringarrayAllocater(char** s);
void stAllocater(char** s);
void strArrAllocater(char*** s);
void myStringCopy(char** dest, char** source);

void stringTok(char** array, char* s, char* delims);

  //crates an object of type GEDline from a string
GEDline* createGEDline(char* s, int i);

TestGED* createTestGED();

  /****CREATES AN OBJECT OF TYPE INDIVIDUALCOPY********/
IndividualCopy* createIndividualCopy(void* gedLine);
  /****CREATES AN INDIVIDUAL*********/
Individual* createIndividual(void* individualCopy);


    /*************CREATES A COPY OF A FAMILY************/
FamilyCopy* createFamilyCopy(void* gedLine);
  /***********CREATES A FAMILY OBJECT**********/
Family* createFamily(void* familyCopy);


        /*********CREATES AN EVENT FROM TWO GED LINES*********/
Event* createEvent(void* type, void* date, void* place);


      /****CREATES A FIELD*********/
Field* createField(void* tag, void* value);

Record* createRecord(GEDline* gedLines);


Header* createHeader(void* headerCopy);
HeaderCopy* createHeaderCopy();


SubmitterCopy* createSubmitterCopy();
Submitter* createSubmitter(void* submitterCopy);


          /***********MUTATORS****************/

          /****************INDIVIDUAL COPY*************/
/****SETS GIVEN NAME********/
void individualCopySetGivenName(void* i, char* givenName);

/*****SETS SURNAME******/
void individualCopySetSurName(void* i, char* surName);

/*****SETS THE LINKS TO EVENTS AND FAMILIES*********/

void individualCopySetSpouseStatus(void* i, char* spouseOf, int familyNumber);



void individualCopySetChildStatus(void* i, char* childOf, int familyNumber);

          /***********SET ATTRIBUTES************/
void individualCopySetSex(void* i, char* sex);





                /************FAMILY COPY MUTATORS*****************/

void familyCopySetHusband(void* f, char* husband);

void familyCopySetWife(void* f, char* wife);

void familyCopySetChild(void* f, char* child, int numChild);





          /**************INDIVIDUAL***************/
void individualSetGivenName(void* i, char* givenName);
void individualSetSurName(void* i, char* surName);


    /****************BASIC DESTROYERS***********/
void freeString(char* s);
void freeStringArray(char** s);

  /*******LIST INIITIALIZERS, COMPARERS, ACCESSORS AND DESTROYERS*********/
  /********FOR GEDLINE LIST************/
List createGEDLineList(char** fileLines, int numLinesInFile, char* (*print)(void* toBePrinted), void (*del)(void* toBeDeleted), int (*comp)(const void* a, const void* b));
char* printGEDline(void* print);
int compareGEDline(const void* a, const void* b);
void destroyGEDline(void* destroy);


    /**************FOR INDIVIDUALCOPY LIST**************/

/**********WRAPPER FOR initializeList************/
List createIndividualCopyList(char* (*print)(void* toBePrinted), void (*del)(void* toBeDeleted), int (*comp)(const void* a, const void* b));

      /*******Wrapper for initailizeList***********/

List createIndividualList(char* (*print)(void* toBePrinted), void (*del)(void* toBeDeleted), int (*comp)(const void* a, const void* b));




        /***************FOR FAMILY COPY LIST***************/

/********WRAPPER FOR INITIALIZELIST*********/
List createFamilyCopyList(char* (*print)(void* toBePrinted), void (*del)(void* toBeDeleted), int (*comp)(const void* a, const void* b));

List createFamilyList(char* (*print)(void* toBePrinted), void (*del)(void* toBeDeleted), int (*comp)(const void* a, const void* b));



          /************FOR EVENT lIST************/
List createEventList(char* (*print)(void* toBePrinted), void (*del)(void* toBeDeleted), int (*comp)(const void* a, const void* b));


List createOtherFieldsList(char* (*print)(void* toBePrinted), void (*del)(void* toBeDeleted), int (*comp)(const void* a, const void* b));



List createRecordList(char* (*print)(void* toBePrinted), void (*del)(void* toBeDeleted), int (*comp)(const void* a, const void*  b));




                /**********DUMMY DESTROYERS****************/
void dummyDelete(void* a);

//HANDLES CONT AND CONC TAG//
void appendValue(List gedList);




  /*********Populaters and Parsers*************/


ErrorCode generalParser(List gedLineList, List recordList, List* iList, List* fList, HeaderCopy* h, SubmitterCopy* s, int* lineNumber);
ErrorCode headerCopyParser(HeaderCopy* head, Record* record);
ErrorCode individualCopyParser(List* individualCopyList, Record* record);
ErrorCode submitterCopyParser(SubmitterCopy* submitter, Record* record);
ErrorCode familyCopyParser(List* familyCopyList, Record* record);


          /**************LINKERS and Populaters**************/

void populateIndividualList(List* gedcomIndividuals, List* iCopyList);
void populateFamilyList(List* gedcomFamilies, List* fCopyList);


        //Wrapped by getDescendants
void populateDescendantList(List* theDescendants, Individual* person);



void linkTwoLists(List* iCopyList, List* fCopyList);

void generalLinker(List* iList, List* fList, HeaderCopy* h, SubmitterCopy* s);







            /*************List Functions - Printers destroyers and COMPARERS******************/
void deleteRecord(void* toBeDeleted);
int compareRecords(const void* a, const void* b);
char* printRecord(void* toBePrinted);


void deleteIndividualCopy(void* toBeDeleted);
int compareIndividualCopies(const void* first,const void* second);
char* printIndividualCopy(void* toBePrinted);

void deleteFamilyCopy(void* toBeDeleted);
int compareFamilyCopies(const void* first,const void* second);
char* printFamilyCopy(void* toBePrinted);

void deleteSubmitterCopy(void* toBeDeleted);
void deleteHeaderCopy(void* toBeDeleted);

void deleteHeader(void* toBeDeleted);
void deleteSubmitter(void* toBeDeleted);


#endif
