
#ifndef _MACROS_
#define _MACROS_

#define MAX_LINE_LENGTH 255




#endif
